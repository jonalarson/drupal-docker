#!/bin/sh
# $Id$

curl --silent --compressed http://example.com/cron.php
